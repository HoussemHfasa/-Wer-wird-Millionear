#include "anmeldenseite.h"

AnmeldenSeite::AnmeldenSeite(QWidget *parent)
    : QWidget(parent)
{
    // Add any initialization code or UI elements for your AnmeldenSeite page
}
