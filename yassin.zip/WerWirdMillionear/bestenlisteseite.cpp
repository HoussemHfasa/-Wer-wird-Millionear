#include "bestenlisteseite.h"

BestenlisteSeite::BestenlisteSeite(QWidget *parent)
    : QWidget(parent)
{
    // Add any initialization code or UI elements for your BestenlisteSeite page
}
