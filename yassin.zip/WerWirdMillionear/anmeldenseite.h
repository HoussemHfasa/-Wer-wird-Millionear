#ifndef ANMELDENSEITE_H
#define ANMELDENSEITE_H

#include <QWidget>

class AnmeldenSeite : public QWidget
{
    Q_OBJECT

public:
    AnmeldenSeite(QWidget *parent = nullptr);
};

#endif // ANMELDENSEITE_H
