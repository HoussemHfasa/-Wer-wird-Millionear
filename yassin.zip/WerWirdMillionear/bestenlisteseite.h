#ifndef BESTENLISTESEITE_H
#define BESTENLISTESEITE_H

#include <QWidget>

class BestenlisteSeite : public QWidget
{
    Q_OBJECT

public:
    BestenlisteSeite(QWidget *parent = nullptr);
};

#endif // BESTENLISTESEITE_H
